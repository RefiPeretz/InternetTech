HTML TAGS:
1.table
2.td
3.th
4.tbody
5.thead
6.div
7.p
8.title
9.img
10.strong

In css file
CSS Styles:
1.position
2.box-shadow
3.border-collapse
4.background-image
5.font-family
6.padding
7.text-align
8.animation-duration
9.font-weight
10.color